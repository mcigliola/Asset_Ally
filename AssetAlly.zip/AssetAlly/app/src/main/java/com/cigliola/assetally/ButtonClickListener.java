package com.cigliola.assetally;

public interface ButtonClickListener {
    void onSave();

    void onDelete();

    void onCancel();
}
